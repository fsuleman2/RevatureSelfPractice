package studentDAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.exception.BusinessException;
import com.student.DAO.StudentDAO;
import com.student.dbutil.PostgresConnection;
import com.student.model.Student;


public class StudentDAOImpl implements StudentDAO{

	public List<Student> getAllStudentDetails() throws BusinessException {
		Student student = new Student();
		List<Student> list = new ArrayList<>();
		try(Connection connection = PostgresConnection.getConnection()){
			String sql = "select studentname,studentage from testing_schema.studenttable";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();
		while(resultSet.next()) {
				
				student.setStudentname(resultSet.getString("studentname"));
				student.setStudentage(resultSet.getInt("studentage"));
				list.add(student);
			}
		System.out.println(list.size());
		} catch (ClassNotFoundException | SQLException e) {
			
		}
		return list;
	}

}
