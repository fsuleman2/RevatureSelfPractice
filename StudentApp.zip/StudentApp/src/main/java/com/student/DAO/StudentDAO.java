package com.student.DAO;

import java.util.List;

import com.exception.BusinessException;
import com.student.model.Student;

public interface StudentDAO {
	public List<Student> getAllStudentDetails() throws BusinessException;
}
