package com.student.service.Impl;

import java.util.ArrayList;
import java.util.List;

import com.exception.BusinessException;
import com.student.DAO.StudentDAO;
import com.student.model.Student;
import com.student.service.StudentService;

import studentDAOImpl.StudentDAOImpl;

public class StudentServiceImpl implements StudentService{

	public List<Student> getAllStudentDetails() throws BusinessException {
		StudentDAO studentDAO = new StudentDAOImpl();
		List<Student> list = new ArrayList<>();
		Student student = new Student();
	if(student.getStudentname()!=null && student.getStudentage()!=0) {
		list= studentDAO.getAllStudentDetails();
	}
		return list;
	}

	

}
