package com.student.service;

import java.util.List;

import com.exception.BusinessException;
import com.student.model.Student;

public interface StudentService {
public List<Student> getAllStudentDetails() throws BusinessException;
}
