package com.student.main;

import java.util.List;
import java.util.Scanner;

import com.exception.BusinessException;
import com.student.model.Student;
import com.student.service.StudentService;
import com.student.service.Impl.StudentServiceImpl;

public class StudentMain {

	public static void main(String[] args) {
		System.out.println("Student Details are");
		Student student = new Student();
		StudentService studentService = new StudentServiceImpl();
		
		try {
			List<Student> slist=studentService.getAllStudentDetails();
			for(Student l : slist) {
				System.out.println(l);
			}
		} catch (BusinessException e) {
			System.out.println(e.getMessage());
		} 

	}

}
