package com.student.model;

public class Student {
private String studentname;
private int studentage;
public Student() {
	// TODO Auto-generated constructor stub
}
public Student(String studentname, int studentage) {
	super();
	this.studentname = studentname;
	this.studentage = studentage;
}
public String getStudentname() {
	return studentname;
}
public void setStudentname(String studentname) {
	this.studentname = studentname;
}
public int getStudentage() {
	return studentage;
}
public void setStudentage(int studentage) {
	this.studentage = studentage;
}
@Override
public String toString() {
	return "Student [studentname=" + studentname + ", studentage=" + studentage + "]";
}
}
